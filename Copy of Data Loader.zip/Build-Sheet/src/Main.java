import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Base64;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class Main {

    public static void main(String[] args) throws IOException {

	    String baseUrl, username, company,password;
		String excelFilePath = "Build_Sheet.xls";
		
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		Workbook workbook = new HSSFWorkbook(inputStream);
			
			// Get Configuration Values from this sheet
			Sheet firstSheet = workbook.getSheet("Config");
			Iterator<Row> iterator = firstSheet.iterator();
				
				Row row1 = iterator.next();	
				Iterator<Cell> cellIterator = row1.cellIterator();
					  cellIterator.next();
					Cell cellB1 = cellIterator.next();
					baseUrl = cellB1.getStringCellValue();
					
				Row row2 = iterator.next();
				Iterator<Cell> cellIterator2 = row2.cellIterator();
				 cellIterator2.next();
				Cell cellB2 = cellIterator2.next();
				username = cellB2.getStringCellValue();
				
				Row row3 = iterator.next();	
				Iterator<Cell> cellIterator3 = row3.cellIterator();
					 cellIterator3.next();
					Cell cellB3 = cellIterator3.next();
					password = cellB3.getStringCellValue();
				
				Row row4 = iterator.next();	
					Iterator<Cell> cellIterator4 = row4.cellIterator();
						 cellIterator4.next();
						Cell cellB4 = cellIterator4.next();
						company = cellB4.getStringCellValue();
			
			// Create Basic Authorization key			
		         String authString= username + "@" + company + ":" + password;
			    byte[] message = authString.getBytes();
                String authStringEncoded = Base64.getEncoder().encodeToString(message);
 ////////////////////////////////////////////////////////////////////////////////////////              
            // Check if Work Zone Sheet has data to upload
	       Sheet SheetWZ = workbook.getSheet("Work Zone");
									
		      Iterator<Row> iteratorWZ = SheetWZ.iterator(); iteratorWZ.next();
		      Row WZrow = iteratorWZ.next();	
		      String WZCell = WZrow.getCell(0).getStringCellValue() ;
		      if (!WZCell.isEmpty())
		          {
		             Work_Zone WZ_POST = new Work_Zone(baseUrl, authStringEncoded, SheetWZ) ;
		          WZ_POST.postData(); // POST Call to Work Skill Rest API 
			      }
		      
////////////////////////////////////////////////////////////////////////////////////////              		      
	            // Check if WZ1Sheet (Work Zone with Key) has data to upload
		       Sheet SheetWZ1 = workbook.getSheet("WZ1");
										
			      Iterator<Row> iteratorWZ1 = SheetWZ1.iterator(); iteratorWZ1.next();
			      Row WZrow1 = iteratorWZ1.next();	
			      String WZCell1 = WZrow1.getCell(0).getStringCellValue() ;
			      if (!WZCell1.isEmpty())
			          {
			             WZ1 WZ1_POST = new WZ1(baseUrl, authStringEncoded, SheetWZ1) ;
			          WZ1_POST.postData(); // POST Call to Work Skill Rest API 
				      }
////////////////////////////////////////////////////////////////////////////////////////	    
		 // Check if Work Skill Sheet has data to upload
	       Sheet SheetWS = workbook.getSheet("Work Skill");
									
		      Iterator<Row> iteratorWS = SheetWS.iterator(); iteratorWS.next();
		      Row WSrow = iteratorWS.next();	
		      String WSCell = WSrow.getCell(0).getStringCellValue() ;
		      if (!WSCell.isEmpty())
		          {
		             Work_Skill WS_PUT = new Work_Skill(baseUrl, authStringEncoded, SheetWS) ;
		             WS_PUT.putData(); // PUT Call to Work Skill Rest API 
			      }
		    
////////////////////////////////////////////////////////////////////////////////////////		      
				 // Check if Work Skill Group Sheet has data to upload
		       Sheet SheetWSG = workbook.getSheet("Work Skill Group");
										
			      Iterator<Row> iteratorWSG = SheetWSG.iterator(); iteratorWSG.next();
			      Row WSGrow = iteratorWSG.next();	
			      String WSGCell = WSGrow.getCell(0).getStringCellValue() ;   
			      if (!WSGCell.isEmpty())
			          {
			    	   Work_Skill_Group WSG_PUT = new Work_Skill_Group(baseUrl, authStringEncoded, SheetWSG) ;
			    	   WSG_PUT.putData(); // PUT Call to Work Skill Group Rest API 
				      }
////////////////////////////////////////////////////////////////////////////////////////
					 // Check if Work Skill Condition Sheet has data to upload
			       Sheet SheetWSC = workbook.getSheet("Work Skill Condition");
											
				      Iterator<Row> iteratorWSC = SheetWSC.iterator(); iteratorWSC.next();
				      Row WSCrow = iteratorWSC.next();	
				      String WSCCell = WSCrow.getCell(0).getStringCellValue() ;   
				      if (!WSCCell.isEmpty())
				          {
				    	   Work_Skill_Condition WSC_PUT = new Work_Skill_Condition(baseUrl, authStringEncoded, SheetWSC) ;
				    	 WSC_PUT.putData(); // PUT Call to Work Skill Condition Rest API 
					      }
////////////////////////////////////////////////////////////////////////////////////////				      
						 // Check if Resource data  Sheet has data to upload
				       Sheet SheetRes = workbook.getSheet("Resource Data");
												
					      Iterator<Row> iteratorRes = SheetRes.iterator(); iteratorRes.next();
					      Row Resrow = iteratorRes.next();	
					      String ResCell1 = Resrow.getCell(0).getStringCellValue() ;   
					      
					      // Get the Mapping from Resource Mapping Sheet
					       Sheet SheetResMap = workbook.getSheet("Resource Mapping");

					      if (!ResCell1.isEmpty())
					          {
					    	   Resource Res_PUT = new Resource (baseUrl, authStringEncoded, SheetRes, SheetResMap) ;
					           Res_PUT.putData(); // PUT Call to Resource Rest API 
						      } 
					      
////////////////////////////////////////////////////////////////////////////////////////					      
				            // Check if Work Skill for Resource Sheet has data to upload
					       Sheet SheetWSFR = workbook.getSheet("Work Skill for Resource");
													
						      Iterator<Row> iteratorWSFR = SheetWSFR.iterator(); iteratorWSFR.next();
						      Row WSFRrow = iteratorWSFR.next();	
						      String WSFRCell = WSFRrow.getCell(0).getStringCellValue() ;
						      if (!WSFRCell.isEmpty())
						          {
						         WSFR WSFR_POST = new WSFR(baseUrl, authStringEncoded, SheetWSFR) ;
						         WSFR_POST.postData(); // POST Call to Work Skill Rest API 
							      }
////////////////////////////////////////////////////////////////////////////////////////		      
			       //Write status to excel file
            FileOutputStream outputstream = new FileOutputStream(new File(excelFilePath));
              workbook.write(outputstream);
             outputstream.close();
              
		   inputStream.close();
    }
}
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import java.util.Iterator;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Resource {

	private final String baseUrl;
	private final String authStringEncoded;
	private final Sheet sheetWS;
	private final Sheet SheetResMap;
	public Resource(String baseUrl, String authStringEncoded, Sheet sheetWS, Sheet SheetResMap) {

		this.baseUrl = baseUrl;
		this.authStringEncoded = authStringEncoded;
		this.sheetWS = sheetWS;
		this.SheetResMap = SheetResMap;
	}

	public void putData() throws IOException

	{
		// Read Mapping and Data Type from Resource Mapping Sheet
		String[][] M = new String[100][3];
		int m = 1;
		Iterator<Row> rowiteratorMap = SheetResMap.iterator();

		while (rowiteratorMap.hasNext()) {
			Row rowMap = rowiteratorMap.next();
			Iterator<Cell> cellIteratorMap = rowMap.cellIterator();
			cellIteratorMap.next();

			// Reading Mapping
			Cell MapCell = cellIteratorMap.next();
			M[m][1] = MapCell.getStringCellValue();

			// Reading Data Type
			Cell DataTypeCell = cellIteratorMap.next();
			M[m][2] = DataTypeCell.getStringCellValue();
			m++;
		}

		// Reading data from data sheet

		int a = 1, b = 1;
		String[][] Data = new String[100][100];
		String res_name = "";
		Iterator<Row> rowiterator = sheetWS.iterator();
		rowiterator.next();

		while (rowiterator.hasNext()) {

			Row row = rowiterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			b = 1;

			while (cellIterator.hasNext()) {
				Cell DataCell = cellIterator.next();
				Data[a][b] = DataCell.getStringCellValue().toString();
				b++;
			}
			a++;
		}

		// Creating the put request

		String media = "";

		for (int i = 1; i < a; i++)

		{
			res_name = Data[i][7];
			for (int j = 1; j < m; j++) // read data till the mapping sheet,
										// thats why m is used
			{
				if ("String".equals(M[j][2]))
				{
					media = media + "\r\n  \"" + M[j][1] + "\": \"" + Data[i][j] + "\",";
				}

				else {
					media = media + "\r\n  \"" + M[j][1] + "\": " + Data[i][j] + ",";
				}				
			}
			
			// Creating User if Resource is Tech
			 if ("Tech".equals(Data[i][6]))
			{
				 OkHttpClient client_Tech = new OkHttpClient();

				 MediaType mediaType_Tech = MediaType.parse("application/octet-stream");
				 RequestBody body_Tech = RequestBody.create(mediaType_Tech, "{\n  \"name\": \"" + res_name + "\",\n  \"mainResourceId\": \"" + res_name + "\",\n  \"language\": \"en\",\n  \"timeZone\": \"Arizona\",\n  \"userType\": \"User_Type_1\",\n  \"password\": \"" + res_name + "\",\n  \"resources\": [\"" + res_name + "\"]\n}");
				 Request request_Tech = new Request.Builder()
				   .url("https://" + baseUrl + "/rest/ofscCore/v1/resources/" + res_name)
				   .put(body_Tech)
				   .addHeader("authorization", "Basic " + authStringEncoded)
				   .build();

				 Response response_Tech = client_Tech.newCall(request_Tech).execute();
				 System.out.println(response_Tech.body().string());
				 System.out.println(response_Tech.message());

			}
			
			System.out.println();
			media = media.substring(0, media.length() - 1);
			media = "\r\n  {  " + media + "\r\n  }";
			System.out.println(media);

			// call the REST API
			OkHttpClient client = new OkHttpClient();
			MediaType mediaType = MediaType.parse("application/octet-stream");
			RequestBody body = RequestBody.create(mediaType, media);
			Request request = new Request.Builder()
					.url("https://" + baseUrl + "/rest/ofscCore/v1/resources/" + res_name)
					.put(body)
					.addHeader("authorization", "Basic " + authStringEncoded)
					.build();

			Response response = client.newCall(request).execute();
			System.out.println(response.body().string());
			System.out.println(response.message());
			media = "";
		}
	}
}
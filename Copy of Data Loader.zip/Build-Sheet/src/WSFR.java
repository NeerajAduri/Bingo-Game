import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import java.util.Iterator;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WSFR {
    private final String baseUrl;
    private final String authStringEncoded;
    private final Sheet sheet;
   
      public WSFR(String baseUrl, String authStringEncoded, Sheet sheet) {
        this.baseUrl = baseUrl;
        this.authStringEncoded = authStringEncoded;
        this.sheet = sheet; 
    }
    
    public void postData() throws  IOException
    {
    	int i = 0, j=1, k=1;
    	String[] resourceId = new String [100], workSkill =new String [100], Ratio =new String [100];
    	String[] startDate =new String [100], endDate =new String [100];
    	
        Iterator<Row> rowiterator = sheet.iterator();
					rowiterator.next();
					while (rowiterator.hasNext()) {
						Row row = rowiterator.next();	 
						Iterator<Cell> cellIterator1 = row.cellIterator();
						 i++;
								Cell resourceIdCell = cellIterator1.next(); 	 
								resourceId[i] = resourceIdCell.getStringCellValue();
								
								 Cell workSkillCell = cellIterator1.next();
								 workSkill[i] = workSkillCell.getStringCellValue();
								
								Cell RatioCell = cellIterator1.next();
								Ratio[i] = RatioCell.getStringCellValue();
							
								Cell startDateCell = cellIterator1.next();
								startDate[i] = startDateCell.getStringCellValue();   
								
								Cell endDateCell = cellIterator1.next();
								endDate[i] = endDateCell.getStringCellValue();
					}
					
					
					 for(int m=0;m<=i;m++){  
						 
						 //System.out.println(m+ " Name "+ Name[m] + "Ws "+ WSLabel[m]);
					    }
					
	 					while (j<=i)	
	 					{
								 if( resourceId[j]==resourceId[j+1])
								 {   
								 //System.out.println(j+ " Name J "+ Name[j] + "Name J+1 "+ Name[j+1]);
								 j++;k++; continue;
								 }
								 else
								 {
									//System.out.println(j+ " Name JJ "+ Name[j] + "Name JJ+1 "+ Name[j+1]); 
									String basemedia = "[\r\n\r\n";
									String media; 
									String restmedia= "";
								
									 for(int p=j-k+1;p<=j;p++){  
										 
										 restmedia= restmedia+"{\r\n        \"workSkill\": \""+workSkill[p]+"\",\r\n        \"ratio\": "+Ratio[p]+",\r\n        \"startDate\": \""+startDate[p] +"\",\r\n        \"endDate\": \""+endDate[p]+"\"\r\n    },\r\n" ;
										 //System.out.println("restmedia is"+ restmedia);
									    }  
									 restmedia = restmedia.substring(0, restmedia.length()-1);
									 media = basemedia + restmedia + "\r\n     ]\r\n";
									 System.out.println("media is  "+ media);
									 
									 
									 OkHttpClient client = new OkHttpClient();

									 MediaType mediaType = MediaType.parse("application/octet-stream");
									 RequestBody body = RequestBody.create(mediaType, media );
						
									 Request request = new Request.Builder()
									   .url("https://"+baseUrl+"/rest/ofscCore/v1/resources/"+ resourceId[j]+"/workSkills")
									   .put(body)
									   .addHeader("authorization", "Basic "+ authStringEncoded)
									   .build();

									 Response response = client.newCall(request).execute();
		                               // System.out.println(response.body().string());
		                                System.out.println(response.message()); 
		                                
									 k=1;
									j++;
								}
							
	 					}		

      System.out.println("Setting Work Skill for Resource is done");                  
        
   }                   

}
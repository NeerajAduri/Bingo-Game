import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import java.util.Iterator;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Work_Skill {
    private final String baseUrl;
    private final String authStringEncoded;
    private final Sheet sheetWS;
   
      public Work_Skill(String baseUrl, String authStringEncoded, Sheet sheetWS) {
        this.baseUrl = baseUrl;
        this.authStringEncoded = authStringEncoded;
        //this.password = password;
        this.sheetWS = sheetWS; 
    }
    
    public void putData() throws  IOException
    {
        Iterator<Row> rowiterator = sheetWS.iterator();
					rowiterator.next();
					while (rowiterator.hasNext()) {    
						Row row = rowiterator.next();	 
						Iterator<Cell> cellIterator = row.cellIterator();
						
								Cell NameCell = cellIterator.next();
								String Name = NameCell.getStringCellValue();
								
								Cell SharingCell = cellIterator.next();
								String Sharing = SharingCell.getStringCellValue();
								
								Cell ActiveCell = cellIterator.next();
								String Active = ActiveCell.getStringCellValue();
								
					           // System.out.println("Name "+ Name);
                               // System.out.println("Sharing " + Sharing);
                               // System.out.println("Active "+ Active);
                    
                                // Performing PUT call to OFSC 
                                OkHttpClient client = new OkHttpClient();
                                MediaType mediaType = MediaType.parse("application/octet-stream");

                                RequestBody body = RequestBody.create(mediaType, "{  \r\n    \"active\":"+Active+",\r\n    \"sharing\":\""+Sharing+ "\",\r\n    \"translations\":\r\n    [\r\n        {\r\n            \"language\":\"en\",  \r\n            \"name\":\""+Name +"\"\r\n        }\r\n    ]\r\n}");
                                Request request = new Request.Builder()
                                    .url("https://"+baseUrl+"/rest/ofscMetadata/v1/workSkills/"+Name)
                                    .put(body)
                                    .addHeader("authorization", "Basic "+ authStringEncoded)
                                    .build();

                                Response response = client.newCall(request).execute();
                               // System.out.println(response.body().string());
                                System.out.println(response.message());
                                
                                // Setting response in excel sheet
                                int colInd =  ActiveCell.getColumnIndex() + 1;
                                Cell cell = row.createCell(colInd);
                                cell.setCellValue(response.message());  
                               
                                 
                        }
              System.out.println("Work Skill creation done");
   }        
    

}

import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import java.util.Iterator;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Work_Skill_Condition {
    private final String baseUrl;
    private final String authStringEncoded;
    private final Sheet sheetWSG;
   
      public Work_Skill_Condition(String baseUrl, String authStringEncoded, Sheet sheetWSG) {
        this.baseUrl = baseUrl;
        this.authStringEncoded = authStringEncoded;
        //this.password = password;
        this.sheetWSG = sheetWSG; 
    }
    
    public void putData() throws  IOException
    {
    	int i = 0, j=1, cl=1; 
    	String[] internalId =new String [1000], skillLabel =new String [1000], requiredLevel =new String [1000], preferableLevel =new String [1000];
    	String[] conditionLabel =new String [1000], conditionFunc =new String [1000], conditionValueList =new String [1000];
    	
        Iterator<Row> rowiterator = sheetWSG.iterator();
					rowiterator.next();
					while (rowiterator.hasNext()) {    
						Row row = rowiterator.next();	 
						Iterator<Cell> cellIterator1 = row.cellIterator();
						 i++;
								Cell internalIdCell = cellIterator1.next(); 	 
								internalId[i] = internalIdCell.getStringCellValue();
								
								 Cell skillLabelCell = cellIterator1.next();
								 skillLabel[i] = skillLabelCell.getStringCellValue();
								
								Cell requiredLevelCell = cellIterator1.next();
								requiredLevel[i] = requiredLevelCell.getStringCellValue();
							
								Cell preferableLevelCell = cellIterator1.next();
								preferableLevel[i] = preferableLevelCell.getStringCellValue();   
								
								Cell conditionLabelCell = cellIterator1.next();
								conditionLabel[i] = conditionLabelCell.getStringCellValue();
								
								Cell conditionFuncCell = cellIterator1.next();
								conditionFunc[i] = conditionFuncCell.getStringCellValue();

								Cell conditionValueListCell = cellIterator1.next();
								conditionValueList[i] = conditionValueListCell.getStringCellValue();
					}
					
					

					 String basemedia = "{\n    \"items\": [\n";
					 String[] restmedia =new String [1000] ;String media = ""; int rm=1;
					 
					 
					 for(int m=0;m<1000;m++){  
						 restmedia[m] = ""; 
					}
					 
					 while (j<=i)	
	 					{  //System.out.println("j "+j +" rm "+rm);  
						 if(internalId[j] == internalId[j+1])
							 {
								 if(conditionLabel[j]==conditionLabel[j+1])
								 {
									 cl++;
								 }
								 else
								 {
									 restmedia[rm]=restmedia[rm]+ "           {\n             \"label\": \""+conditionLabel[j]+"\",\n             \"function\": \"in\",\n             \"valueList\": [\n";  
									
									 for(int m = j-cl+1;m<=j;m++)
									 {
										 restmedia[rm]= restmedia[rm]+  "                  \""+conditionValueList[m]+"\",\n"; 
									 }
								
									 restmedia[rm] = restmedia[rm].substring(0, restmedia[rm].length()-2);
									 restmedia[rm] = restmedia[rm] +"\n               ]\n           },\n";
								 cl=1;
								 
								// System.out.println( "Condition Label not matching "+restmedia[rm]);  
								 }
							 }
						 else
							 {
								 restmedia[rm]= "	{\n          \"label\": \""+skillLabel[j]+"\",\n          \"requiredLevel\": "+requiredLevel[j]+",\n          \"preferableLevel\": "+preferableLevel[j]+",\n          \"conditions\": [\n" + restmedia[rm];
								 restmedia[rm]=restmedia[rm]+ "           {\n             \"label\": \""+conditionLabel[j]+"\",\n             \"function\": \"in\",\n             \"valueList\": [\n";  
								 
								 for(int m = j-cl+1;m<=j;m++)
								 { 
									 restmedia[rm]= restmedia[rm]+  "                  \""+conditionValueList[m]+"\",\n"; 
								 }

							 restmedia[rm] = restmedia[rm].substring(0, restmedia[rm].length()-2);
							 restmedia[rm] = restmedia[rm] +"\n               ]\n           }";
							 restmedia[rm]=restmedia[rm]+ "\n      ],\n      \"dependencies\": [],\n      \"internalId\": "+internalId[j]+"\n      },\n";
								 
								 
								// System.out.println( "Internal Id not matching "+restmedia[rm]);  
								 cl=1;rm++;
							 }
						 j++;	

	 					}

					 for(int m=1;m<rm;m++){  
						 media = media+restmedia[m] ; 
					}
					 media = media.substring(0, media.length()-2);
					media = basemedia+ media+ "\n  ]\n}";
			System.out.println( media);  
				 
				 OkHttpClient client = new OkHttpClient();

				 MediaType mediaType = MediaType.parse("application/octet-stream");
				 RequestBody body = RequestBody.create(mediaType, media );
	
				 Request request = new Request.Builder()
				   .url("https://"+baseUrl+"/rest/ofscMetadata/v1/workSkillConditions")
				   .put(body)
				   .addHeader("authorization", "Basic "+ authStringEncoded)
				   .build();

				 Response response = client.newCall(request).execute();
                   // System.out.println(response.body().string());
                    System.out.println(response.message());

      System.out.println("Work Skill Condition creation done");                  
        
   }                   

}
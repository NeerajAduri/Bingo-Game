import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import java.util.Iterator;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Work_Skill_Group {
    private final String baseUrl;
    private final String authStringEncoded;
    private final Sheet sheetWSG;
   
      public Work_Skill_Group(String baseUrl, String authStringEncoded, Sheet sheetWSG) {
        this.baseUrl = baseUrl;
        this.authStringEncoded = authStringEncoded;
        //this.password = password;
        this.sheetWSG = sheetWSG; 
    }
    
    public void putData() throws  IOException
    {
    	int i = 0, j=1, k=1;
    	String[] Name = new String [100], WSLabel =new String [100], Ratio =new String [100];
    	String[] Active =new String [100], assignToResource =new String [100], addToCapacityCategory =new String [100];
    	
        Iterator<Row> rowiterator = sheetWSG.iterator();
					rowiterator.next();
					while (rowiterator.hasNext()) {    
						Row row = rowiterator.next();	 
						Iterator<Cell> cellIterator1 = row.cellIterator();
						 i++;
								Cell NameCell = cellIterator1.next(); 	 
								 Name[i] = NameCell.getStringCellValue();
								
								 Cell WSLabelCell = cellIterator1.next();
								 WSLabel[i] = WSLabelCell.getStringCellValue();
								
								Cell RatioCell = cellIterator1.next();
								Ratio[i] = RatioCell.getStringCellValue();
							
								Cell ActiveCell = cellIterator1.next();
								 Active[i] = ActiveCell.getStringCellValue();   
								
								Cell assignToResourceCell = cellIterator1.next();
								 assignToResource[i] = assignToResourceCell.getStringCellValue();
								
								Cell addToCapacityCategoryCell = cellIterator1.next();
								 addToCapacityCategory[i] = addToCapacityCategoryCell.getStringCellValue();
								
					}
					
					
					 for(int m=0;m<=i;m++){  
						 
						 //System.out.println(m+ " Name "+ Name[m] + "Ws "+ WSLabel[m]);
					    }
					
				
					
								 
	 					while (j<=i)	
	 					{
								 if( Name[j]==Name[j+1])
								 {   
								 //System.out.println(j+ " Name J "+ Name[j] + "Name J+1 "+ Name[j+1]);
								 j++;k++; continue;
								 }
								 else
								 {
									//System.out.println(j+ " Name JJ "+ Name[j] + "Name JJ+1 "+ Name[j+1]); 
									String basemedia = "{  \n    \"active\":"+Active[j]+",\n    \"assignToResource\":"+assignToResource[j]+",\n    \"addToCapacityCategory\":"+addToCapacityCategory[j]+",\n    \"translations\":[\n        {  \n            \"language\":\"en\",  \n            \"name\":\""+Name[j]+"\"\n        }\n    ],\n    \"workSkills\":[";
									String media;
									String restmedia= "";
								
									// call_put(Name[], WSLabel[], Ratio[], Active[], assignToResource[], addToCapacityCategory[], j,k);
									 for(int p=j-k+1;p<=j;p++){  
										 
										 restmedia= restmedia+"\n        {  \n            \"label\":\""+WSLabel[p]+"\",\n            \"ratio\":"+Ratio[p]+"\n        }," ;
										 //System.out.println("restmedia is"+ restmedia);
									    }  
									 restmedia = restmedia.substring(0, restmedia.length()-1);
									 media = basemedia + restmedia + "\n    ]\n}";
									 //System.out.println("media is  "+ media);
									 
									 
									 OkHttpClient client = new OkHttpClient();

									 MediaType mediaType = MediaType.parse("application/octet-stream");
									 RequestBody body = RequestBody.create(mediaType, media );
						
									 Request request = new Request.Builder()
									   .url("https://"+baseUrl+"/rest/ofscMetadata/v1/workSkillGroups/"+ Name[j])
									   .put(body)
									   .addHeader("authorization", "Basic "+ authStringEncoded)
									   .build();

									 Response response = client.newCall(request).execute();
		                               // System.out.println(response.body().string());
		                                System.out.println(response.message());
		                                
									 k=1;
									j++;
								}
							
	 					}		


                                
                                // Setting response in excel sheet

      System.out.println("Work Skill Group creation done");                  
        
   }                   

}
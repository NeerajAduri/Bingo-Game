import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import java.util.Iterator;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Work_Zone {
    private final String baseUrl;
    private final String authStringEncoded;
    private final Sheet sheetWS;
   
      public Work_Zone(String baseUrl, String authStringEncoded, Sheet sheetWS) {
        this.baseUrl = baseUrl;
        this.authStringEncoded = authStringEncoded;
        //this.password = password;
        this.sheetWS = sheetWS; 
    }
    
    public void postData() throws  IOException
    {
        Iterator<Row> rowiterator = sheetWS.iterator();
					rowiterator.next();
					while (rowiterator.hasNext()) {    
						Row row = rowiterator.next();	 
						Iterator<Cell> cellIterator = row.cellIterator();
						
								Cell workZoneCell = cellIterator.next();
								String workZone = workZoneCell.getStringCellValue();
								
								Cell statusCell = cellIterator.next();
								String status = statusCell.getStringCellValue();
								
								Cell travelAreaCell = cellIterator.next();
								String travelArea = travelAreaCell.getStringCellValue();
								
								Cell keysCell = cellIterator.next();
								String keys = keysCell.getStringCellValue();
								
                                // Performing PUT call to OFSC 
                                OkHttpClient client = new OkHttpClient();
                                MediaType mediaType = MediaType.parse("application/octet-stream");

                                RequestBody body = RequestBody.create(mediaType, "{\r\n    \"workZoneLabel\": \""+workZone+"\",\r\n    \"status\":        \""+status+"\",\r\n    \"travelArea\":    \""+travelArea+"\",\r\n    \"keys\":          [\""+keys+"\"]\r\n}");
                                Request request = new Request.Builder()
                                    .url("https://"+baseUrl+"/rest/ofscMetadata/v1/workZones")
                                    .post(body)
                                    .addHeader("authorization", "Basic "+ authStringEncoded)
                                    .build();

                                Response response = client.newCall(request).execute();
                                //System.out.println(response.body().string());
                                System.out.println(response.message());
                                
                                // Setting response in excel sheet
                                int colInd =  keysCell.getColumnIndex() + 1;
                                Cell cell = row.createCell(colInd);
                                cell.setCellValue(response.message());  
                                 
                        }
              
   }                   

}
